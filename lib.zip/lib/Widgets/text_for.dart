import 'package:flutter/material.dart';
import 'package:itimaat/View/FontsStyle.dart';


Widget customText ({ String  text, Color color,double size }) => 
    Text(text,style: blueColorStyleMediumWithColor(18, color),);