/// ongoing : [{"id":159,"title":"Ijtimaati management","owner_id":35,"committee_id":8,"description":"","start_date":"2021-12-13 09:52:00","duration":60,"location":null,"meeting_status_id":3,"virtual":0,"order":"TalkingPoints,Decisions,Actions","attendance_status":"Pending","last_activity":"Mazin F Update decision Approval For the new system 2021-12-05 10:58:36","current_member":{"id":350,"meeting_id":159,"user_id":35,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"user":{"name":"Mazin F","email":"Mazin@ijtimaati.com","image":"http://test.ijtimaati.com/api/public/uploads/images/UEvcaAL11E.jpeg","position":"IT Support","team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},"members":[{"id":347,"meeting_id":159,"user_id":21,"user_email":"","can_edit":0,"attendance_status":"Going","status_reason":null,"user":{"name":"Ahmed Zaid","email":"ahmed@ijtimaati.com","image":"http://test.ijtimaati.com/api/public/uploads/images/Ut7NK4RANu.jpg","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":350,"meeting_id":159,"user_id":35,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"user":{"name":"Mazin F","email":"Mazin@ijtimaati.com","image":"http://test.ijtimaati.com/api/public/uploads/images/UEvcaAL11E.jpeg","position":"IT Support","team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":348,"meeting_id":159,"user_id":37,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"user":{"name":"Jamila","email":"jamila@ijtimaati.com","image":"http://test.ijtimaati.com/api/public/uploads/images/zQD6FoVtg2.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":349,"meeting_id":159,"user_id":38,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"user":{"name":"Hilal","email":"hilal@ijtimaati.com","image":"http://test.ijtimaati.com/api/public/uploads/images/koU0KGKcAO.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"}]}]
/// pending : [{"id":159,"title":"Ijtimaati management","owner_id":35,"committee_id":8,"description":"","start_date":"2021-12-13 09:52:00","duration":60,"location":null,"meeting_status_id":3,"virtual":0,"order":"TalkingPoints,Decisions,Actions","attendance_status":"Pending","last_activity":"Mazin F Update decision Approval For the new system 2021-12-05 10:58:36","current_member":{"id":350,"meeting_id":159,"user_id":35,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"user":{"name":"Mazin F","email":"Mazin@ijtimaati.com","image":"http://test.ijtimaati.com/api/public/uploads/images/UEvcaAL11E.jpeg","position":"IT Support","team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},"members":[{"id":347,"meeting_id":159,"user_id":21,"user_email":"","can_edit":0,"attendance_status":"Going","status_reason":null,"user":{"name":"Ahmed Zaid","email":"ahmed@ijtimaati.com","image":"http://test.ijtimaati.com/api/public/uploads/images/Ut7NK4RANu.jpg","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":350,"meeting_id":159,"user_id":35,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"user":{"name":"Mazin F","email":"Mazin@ijtimaati.com","image":"http://test.ijtimaati.com/api/public/uploads/images/UEvcaAL11E.jpeg","position":"IT Support","team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":348,"meeting_id":159,"user_id":37,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"user":{"name":"Jamila","email":"jamila@ijtimaati.com","image":"http://test.ijtimaati.com/api/public/uploads/images/zQD6FoVtg2.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":349,"meeting_id":159,"user_id":38,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"user":{"name":"Hilal","email":"hilal@ijtimaati.com","image":"http://test.ijtimaati.com/api/public/uploads/images/koU0KGKcAO.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"}]}]
/// draft : [{"id":159,"title":"Ijtimaati management","owner_id":35,"committee_id":8,"description":"","start_date":"2021-12-13 09:52:00","duration":60,"location":null,"meeting_status_id":3,"virtual":0,"order":"TalkingPoints,Decisions,Actions","attendance_status":"Pending","last_activity":"Mazin F Update decision Approval For the new system 2021-12-05 10:58:36","current_member":{"id":350,"meeting_id":159,"user_id":35,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"user":{"name":"Mazin F","email":"Mazin@ijtimaati.com","image":"http://test.ijtimaati.com/api/public/uploads/images/UEvcaAL11E.jpeg","position":"IT Support","team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},"members":[{"id":347,"meeting_id":159,"user_id":21,"user_email":"","can_edit":0,"attendance_status":"Going","status_reason":null,"user":{"name":"Ahmed Zaid","email":"ahmed@ijtimaati.com","image":"http://test.ijtimaati.com/api/public/uploads/images/Ut7NK4RANu.jpg","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":350,"meeting_id":159,"user_id":35,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"user":{"name":"Mazin F","email":"Mazin@ijtimaati.com","image":"http://test.ijtimaati.com/api/public/uploads/images/UEvcaAL11E.jpeg","position":"IT Support","team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":348,"meeting_id":159,"user_id":37,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"user":{"name":"Jamila","email":"jamila@ijtimaati.com","image":"http://test.ijtimaati.com/api/public/uploads/images/zQD6FoVtg2.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":349,"meeting_id":159,"user_id":38,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"user":{"name":"Hilal","email":"hilal@ijtimaati.com","image":"http://test.ijtimaati.com/api/public/uploads/images/koU0KGKcAO.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"}]}]
/// talkingpoints : [{"id":82,"meeting_id":159,"creator_id":35,"title":"Sales and Marketing Update","duration":60,"description":"Last week update","order":0,"meeting":{"id":159,"title":"Ijtimaati management","owner_id":35,"committee_id":8,"description":"","start_date":"2021-12-13 09:52:00","duration":60,"location":null,"meeting_status_id":3,"virtual":0,"order":"TalkingPoints,Decisions,Actions","attendance_status":"Pending","last_activity":"Mazin F Update decision Approval For the new system 2021-12-05 10:58:36","current_member":{"id":350,"meeting_id":159,"user_id":35,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"user":{"name":"Mazin F","email":"Mazin@ijtimaati.com","image":"http://test.ijtimaati.com/api/public/uploads/images/UEvcaAL11E.jpeg","position":"IT Support","team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},"members":[{"id":347,"meeting_id":159,"user_id":21,"user_email":"","can_edit":0,"attendance_status":"Going","status_reason":null,"user":{"name":"Ahmed Zaid","email":"ahmed@ijtimaati.com","image":"http://test.ijtimaati.com/api/public/uploads/images/Ut7NK4RANu.jpg","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":350,"meeting_id":159,"user_id":35,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"user":{"name":"Mazin F","email":"Mazin@ijtimaati.com","image":"http://test.ijtimaati.com/api/public/uploads/images/UEvcaAL11E.jpeg","position":"IT Support","team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":348,"meeting_id":159,"user_id":37,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"user":{"name":"Jamila","email":"jamila@ijtimaati.com","image":"http://test.ijtimaati.com/api/public/uploads/images/zQD6FoVtg2.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":349,"meeting_id":159,"user_id":38,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"user":{"name":"Hilal","email":"hilal@ijtimaati.com","image":"http://test.ijtimaati.com/api/public/uploads/images/koU0KGKcAO.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"}]}}]
/// decision : [{"id":58,"meeting_id":159,"creator_id":35,"title":"Approval For the new system","deadline":"2021-12-05 09:08:08","description":null,"order":0,"meeting":{"id":159,"title":"Ijtimaati management","owner_id":35,"committee_id":8,"description":"","start_date":"2021-12-13 09:52:00","duration":60,"location":null,"meeting_status_id":3,"virtual":0,"order":"TalkingPoints,Decisions,Actions","attendance_status":"Pending","last_activity":"Mazin F Update decision Approval For the new system 2021-12-05 10:58:36","current_member":{"id":350,"meeting_id":159,"user_id":35,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"user":{"name":"Mazin F","email":"Mazin@ijtimaati.com","image":"http://test.ijtimaati.com/api/public/uploads/images/UEvcaAL11E.jpeg","position":"IT Support","team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},"members":[{"id":347,"meeting_id":159,"user_id":21,"user_email":"","can_edit":0,"attendance_status":"Going","status_reason":null,"user":{"name":"Ahmed Zaid","email":"ahmed@ijtimaati.com","image":"http://test.ijtimaati.com/api/public/uploads/images/Ut7NK4RANu.jpg","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":350,"meeting_id":159,"user_id":35,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"user":{"name":"Mazin F","email":"Mazin@ijtimaati.com","image":"http://test.ijtimaati.com/api/public/uploads/images/UEvcaAL11E.jpeg","position":"IT Support","team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":348,"meeting_id":159,"user_id":37,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"user":{"name":"Jamila","email":"jamila@ijtimaati.com","image":"http://test.ijtimaati.com/api/public/uploads/images/zQD6FoVtg2.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":349,"meeting_id":159,"user_id":38,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"user":{"name":"Hilal","email":"hilal@ijtimaati.com","image":"http://test.ijtimaati.com/api/public/uploads/images/koU0KGKcAO.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"}]}}]
/// action : [{"id":28,"meeting_id":159,"creator_id":35,"title":"Testing new version of ijtimaati","open_till":"2021-12-05 09:08:52","priority":"Low","description":null,"order":0,"meeting":{"id":159,"title":"Ijtimaati management","owner_id":35,"committee_id":8,"description":"","start_date":"2021-12-13 09:52:00","duration":60,"location":null,"meeting_status_id":3,"virtual":0,"order":"TalkingPoints,Decisions,Actions","attendance_status":"Pending","last_activity":"Mazin F Update decision Approval For the new system 2021-12-05 10:58:36","current_member":{"id":350,"meeting_id":159,"user_id":35,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"user":{"name":"Mazin F","email":"Mazin@ijtimaati.com","image":"http://test.ijtimaati.com/api/public/uploads/images/UEvcaAL11E.jpeg","position":"IT Support","team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},"members":[{"id":347,"meeting_id":159,"user_id":21,"user_email":"","can_edit":0,"attendance_status":"Going","status_reason":null,"user":{"name":"Ahmed Zaid","email":"ahmed@ijtimaati.com","image":"http://test.ijtimaati.com/api/public/uploads/images/Ut7NK4RANu.jpg","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":350,"meeting_id":159,"user_id":35,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"user":{"name":"Mazin F","email":"Mazin@ijtimaati.com","image":"http://test.ijtimaati.com/api/public/uploads/images/UEvcaAL11E.jpeg","position":"IT Support","team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":348,"meeting_id":159,"user_id":37,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"user":{"name":"Jamila","email":"jamila@ijtimaati.com","image":"http://test.ijtimaati.com/api/public/uploads/images/zQD6FoVtg2.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":349,"meeting_id":159,"user_id":38,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"user":{"name":"Hilal","email":"hilal@ijtimaati.com","image":"http://test.ijtimaati.com/api/public/uploads/images/koU0KGKcAO.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"}]}}]
/// upcoming : 1
/// counts : {"going":0,"notgoing":0,"pending":1,"maybe":0}

class DashboardResponseModel {
  List<Ongoing> _ongoing;
  List<Pending> _pending;
  List<Draft> _draft;
  List<Talkingpoints> _talkingpoints;
  List<Decision> _decision;
  List<ActionResponse> _action;
  int _upcoming;
  Counts _counts;

  List<Ongoing> get ongoing => _ongoing;
  List<Pending> get pending => _pending;
  List<Draft> get draft => _draft;
  List<Talkingpoints> get talkingpoints => _talkingpoints;
  List<Decision> get decision => _decision;
  List<ActionResponse> get action => _action;
  int get upcoming => _upcoming;
  Counts get counts => _counts;

  DashboardResponseModel({
      List<Ongoing> ongoing, 
      List<Pending> pending, 
      List<Draft> draft, 
      List<Talkingpoints> talkingpoints, 
      List<Decision> decision, 
      List<ActionResponse> action,
      int upcoming, 
      Counts counts}){
    _ongoing = ongoing;
    _pending = pending;
    _draft = draft;
    _talkingpoints = talkingpoints;
    _decision = decision;
    _action = action;
    _upcoming = upcoming;
    _counts = counts;
}

  DashboardResponseModel.fromJson(dynamic json) {
    if (json['ongoing'] != null) {
      _ongoing = [];
      json['ongoing'].forEach((v) {
        _ongoing.add(Ongoing.fromJson(v));
      });
    }
    if (json['pending'] != null) {
      _pending = [];
      json['pending'].forEach((v) {
        _pending.add(Pending.fromJson(v));
      });
    }
    if (json['draft'] != null) {
      _draft = [];
      json['draft'].forEach((v) {
        _draft.add(Draft.fromJson(v));
      });
    }
    if (json['talkingpoints'] != null) {
      _talkingpoints = [];
      json['talkingpoints'].forEach((v) {
        _talkingpoints.add(Talkingpoints.fromJson(v));
      });
    }
    if (json['decision'] != null) {
      _decision = [];
      json['decision'].forEach((v) {
        _decision.add(Decision.fromJson(v));
      });
    }
    if (json['action'] != null) {
      _action = [];
      json['action'].forEach((v) {
        _action.add(ActionResponse.fromJson(v));
      });
    }
    _upcoming = json['upcoming'];
    _counts = json['counts'] != null ? Counts.fromJson(json['counts']) : null;
  }

  Map<String, dynamic> toJson() {
    var map = <String, dynamic>{};
    if (_ongoing != null) {
      map['ongoing'] = _ongoing.map((v) => v.toJson()).toList();
    }
    if (_pending != null) {
      map['pending'] = _pending.map((v) => v.toJson()).toList();
    }
    if (_draft != null) {
      map['draft'] = _draft.map((v) => v.toJson()).toList();
    }
    if (_talkingpoints != null) {
      map['talkingpoints'] = _talkingpoints.map((v) => v.toJson()).toList();
    }
    if (_decision != null) {
      map['decision'] = _decision.map((v) => v.toJson()).toList();
    }
    if (_action != null) {
      map['action'] = _action.map((v) => v.toJson()).toList();
    }
    map['upcoming'] = _upcoming;
    if (_counts != null) {
      map['counts'] = _counts.toJson();
    }
    return map;
  }

}

/// going : 0
/// notgoing : 0
/// pending : 1
/// maybe : 0

class Counts {
  int _going;
  int _notgoing;
  int _pending;
  int _maybe;

  int get going => _going;
  int get notgoing => _notgoing;
  int get pending => _pending;
  int get maybe => _maybe;

  Counts({
      int going, 
      int notgoing, 
      int pending, 
      int maybe}){
    _going = going;
    _notgoing = notgoing;
    _pending = pending;
    _maybe = maybe;
}

  Counts.fromJson(dynamic json) {
    _going = json['going'];
    _notgoing = json['notgoing'];
    _pending = json['pending'];
    _maybe = json['maybe'];
  }

  Map<String, dynamic> toJson() {
    var map = <String, dynamic>{};
    map['going'] = _going;
    map['notgoing'] = _notgoing;
    map['pending'] = _pending;
    map['maybe'] = _maybe;
    return map;
  }

}

/// id : 28
/// meeting_id : 159
/// creator_id : 35
/// title : "Testing new version of ijtimaati"
/// open_till : "2021-12-05 09:08:52"
/// priority : "Low"
/// description : null
/// order : 0
/// meeting : {"id":159,"title":"Ijtimaati management","owner_id":35,"committee_id":8,"description":"","start_date":"2021-12-13 09:52:00","duration":60,"location":null,"meeting_status_id":3,"virtual":0,"order":"TalkingPoints,Decisions,Actions","attendance_status":"Pending","last_activity":"Mazin F Update decision Approval For the new system 2021-12-05 10:58:36","current_member":{"id":350,"meeting_id":159,"user_id":35,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"user":{"name":"Mazin F","email":"Mazin@ijtimaati.com","image":"http://test.ijtimaati.com/api/public/uploads/images/UEvcaAL11E.jpeg","position":"IT Support","team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},"members":[{"id":347,"meeting_id":159,"user_id":21,"user_email":"","can_edit":0,"attendance_status":"Going","status_reason":null,"user":{"name":"Ahmed Zaid","email":"ahmed@ijtimaati.com","image":"http://test.ijtimaati.com/api/public/uploads/images/Ut7NK4RANu.jpg","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":350,"meeting_id":159,"user_id":35,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"user":{"name":"Mazin F","email":"Mazin@ijtimaati.com","image":"http://test.ijtimaati.com/api/public/uploads/images/UEvcaAL11E.jpeg","position":"IT Support","team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":348,"meeting_id":159,"user_id":37,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"user":{"name":"Jamila","email":"jamila@ijtimaati.com","image":"http://test.ijtimaati.com/api/public/uploads/images/zQD6FoVtg2.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":349,"meeting_id":159,"user_id":38,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"user":{"name":"Hilal","email":"hilal@ijtimaati.com","image":"http://test.ijtimaati.com/api/public/uploads/images/koU0KGKcAO.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"}]}

class ActionResponse {
  int _id;
  int _meetingId;
  int _creatorId;
  String _title;
  String _openTill;
  String _priority;
  dynamic _description;
  int _order;
  Meeting _meeting;

  int get id => _id;
  int get meetingId => _meetingId;
  int get creatorId => _creatorId;
  String get title => _title;
  String get openTill => _openTill;
  String get priority => _priority;
  dynamic get description => _description;
  int get order => _order;
  Meeting get meeting => _meeting;

  ActionResponse({
      int id, 
      int meetingId, 
      int creatorId, 
      String title, 
      String openTill, 
      String priority, 
      dynamic description, 
      int order, 
      Meeting meeting}){
    _id = id;
    _meetingId = meetingId;
    _creatorId = creatorId;
    _title = title;
    _openTill = openTill;
    _priority = priority;
    _description = description;
    _order = order;
    _meeting = meeting;
}

  ActionResponse.fromJson(dynamic json) {
    _id = json['id'];
    _meetingId = json['meeting_id'];
    _creatorId = json['creator_id'];
    _title = json['title'];
    _openTill = json['open_till'];
    _priority = json['priority'];
    _description = json['description'];
    _order = json['order'];
    _meeting = json['meeting'] != null ? Meeting.fromJson(json['meeting']) : null;
  }

  Map<String, dynamic> toJson() {
    var map = <String, dynamic>{};
    map['id'] = _id;
    map['meeting_id'] = _meetingId;
    map['creator_id'] = _creatorId;
    map['title'] = _title;
    map['open_till'] = _openTill;
    map['priority'] = _priority;
    map['description'] = _description;
    map['order'] = _order;
    if (_meeting != null) {
      map['meeting'] = _meeting.toJson();
    }
    return map;
  }

}

/// id : 159
/// title : "Ijtimaati management"
/// owner_id : 35
/// committee_id : 8
/// description : ""
/// start_date : "2021-12-13 09:52:00"
/// duration : 60
/// location : null
/// meeting_status_id : 3
/// virtual : 0
/// order : "TalkingPoints,Decisions,Actions"
/// attendance_status : "Pending"
/// last_activity : "Mazin F Update decision Approval For the new system 2021-12-05 10:58:36"
/// current_member : {"id":350,"meeting_id":159,"user_id":35,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"user":{"name":"Mazin F","email":"Mazin@ijtimaati.com","image":"http://test.ijtimaati.com/api/public/uploads/images/UEvcaAL11E.jpeg","position":"IT Support","team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"}
/// members : [{"id":347,"meeting_id":159,"user_id":21,"user_email":"","can_edit":0,"attendance_status":"Going","status_reason":null,"user":{"name":"Ahmed Zaid","email":"ahmed@ijtimaati.com","image":"http://test.ijtimaati.com/api/public/uploads/images/Ut7NK4RANu.jpg","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":350,"meeting_id":159,"user_id":35,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"user":{"name":"Mazin F","email":"Mazin@ijtimaati.com","image":"http://test.ijtimaati.com/api/public/uploads/images/UEvcaAL11E.jpeg","position":"IT Support","team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":348,"meeting_id":159,"user_id":37,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"user":{"name":"Jamila","email":"jamila@ijtimaati.com","image":"http://test.ijtimaati.com/api/public/uploads/images/zQD6FoVtg2.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":349,"meeting_id":159,"user_id":38,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"user":{"name":"Hilal","email":"hilal@ijtimaati.com","image":"http://test.ijtimaati.com/api/public/uploads/images/koU0KGKcAO.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"}]

class Meeting {
  int _id;
  String _title;
  int _ownerId;
  int _committeeId;
  String _description;
  String _startDate;
  int _duration;
  dynamic _location;
  int _meetingStatusId;
  int _virtual;
  String _order;
  String _attendanceStatus;
  String _lastActivity;
  Current_member _currentMember;
  List<Members> _members;

  int get id => _id;
  String get title => _title;
  int get ownerId => _ownerId;
  int get committeeId => _committeeId;
  String get description => _description;
  String get startDate => _startDate;
  int get duration => _duration;
  dynamic get location => _location;
  int get meetingStatusId => _meetingStatusId;
  int get virtual => _virtual;
  String get order => _order;
  String get attendanceStatus => _attendanceStatus;
  String get lastActivity => _lastActivity;
  Current_member get currentMember => _currentMember;
  List<Members> get members => _members;

  Meeting({
      int id, 
      String title, 
      int ownerId, 
      int committeeId, 
      String description, 
      String startDate, 
      int duration, 
      dynamic location, 
      int meetingStatusId, 
      int virtual, 
      String order, 
      String attendanceStatus, 
      String lastActivity, 
      Current_member currentMember, 
      List<Members> members}){
    _id = id;
    _title = title;
    _ownerId = ownerId;
    _committeeId = committeeId;
    _description = description;
    _startDate = startDate;
    _duration = duration;
    _location = location;
    _meetingStatusId = meetingStatusId;
    _virtual = virtual;
    _order = order;
    _attendanceStatus = attendanceStatus;
    _lastActivity = lastActivity;
    _currentMember = currentMember;
    _members = members;
}

  Meeting.fromJson(dynamic json) {
    _id = json['id'];
    _title = json['title'];
    _ownerId = json['owner_id'];
    _committeeId = json['committee_id'];
    _description = json['description'];
    _startDate = json['start_date'];
    _duration = json['duration'];
    _location = json['location'];
    _meetingStatusId = json['meeting_status_id'];
    _virtual = json['virtual'];
    _order = json['order'];
    _attendanceStatus = json['attendance_status'];
    _lastActivity = json['last_activity'];
    _currentMember = json['current_member'] != null ? Current_member.fromJson(json['current_member']) : null;
    if (json['members'] != null) {
      _members = [];
      json['members'].forEach((v) {
        _members.add(Members.fromJson(v));
      });
    }
  }

  Map<String, dynamic> toJson() {
    var map = <String, dynamic>{};
    map['id'] = _id;
    map['title'] = _title;
    map['owner_id'] = _ownerId;
    map['committee_id'] = _committeeId;
    map['description'] = _description;
    map['start_date'] = _startDate;
    map['duration'] = _duration;
    map['location'] = _location;
    map['meeting_status_id'] = _meetingStatusId;
    map['virtual'] = _virtual;
    map['order'] = _order;
    map['attendance_status'] = _attendanceStatus;
    map['last_activity'] = _lastActivity;
    if (_currentMember != null) {
      map['current_member'] = _currentMember.toJson();
    }
    if (_members != null) {
      map['members'] = _members.map((v) => v.toJson()).toList();
    }
    return map;
  }

}

/// id : 347
/// meeting_id : 159
/// user_id : 21
/// user_email : ""
/// can_edit : 0
/// attendance_status : "Going"
/// status_reason : null
/// user : {"name":"Ahmed Zaid","email":"ahmed@ijtimaati.com","image":"http://test.ijtimaati.com/api/public/uploads/images/Ut7NK4RANu.jpg","position":null,"team_name":"","role_name":"","committee":null,"role":null}
/// type : "Viewer"

class Members {
  int _id;
  int _meetingId;
  int _userId;
  String _userEmail;
  int _canEdit;
  String _attendanceStatus;
  dynamic _statusReason;
  User _user;
  String _type;

  int get id => _id;
  int get meetingId => _meetingId;
  int get userId => _userId;
  String get userEmail => _userEmail;
  int get canEdit => _canEdit;
  String get attendanceStatus => _attendanceStatus;
  dynamic get statusReason => _statusReason;
  User get user => _user;
  String get type => _type;

  Members({
      int id, 
      int meetingId, 
      int userId, 
      String userEmail, 
      int canEdit, 
      String attendanceStatus, 
      dynamic statusReason, 
      User user, 
      String type}){
    _id = id;
    _meetingId = meetingId;
    _userId = userId;
    _userEmail = userEmail;
    _canEdit = canEdit;
    _attendanceStatus = attendanceStatus;
    _statusReason = statusReason;
    _user = user;
    _type = type;
}

  Members.fromJson(dynamic json) {
    _id = json['id'];
    _meetingId = json['meeting_id'];
    _userId = json['user_id'];
    _userEmail = json['user_email'];
    _canEdit = json['can_edit'];
    _attendanceStatus = json['attendance_status'];
    _statusReason = json['status_reason'];
    _user = json['user'] != null ? User.fromJson(json['user']) : null;
    _type = json['type'];
  }

  Map<String, dynamic> toJson() {
    var map = <String, dynamic>{};
    map['id'] = _id;
    map['meeting_id'] = _meetingId;
    map['user_id'] = _userId;
    map['user_email'] = _userEmail;
    map['can_edit'] = _canEdit;
    map['attendance_status'] = _attendanceStatus;
    map['status_reason'] = _statusReason;
    if (_user != null) {
      map['user'] = _user.toJson();
    }
    map['type'] = _type;
    return map;
  }

}

/// name : "Ahmed Zaid"
/// email : "ahmed@ijtimaati.com"
/// image : "http://test.ijtimaati.com/api/public/uploads/images/Ut7NK4RANu.jpg"
/// position : null
/// team_name : ""
/// role_name : ""
/// committee : null
/// role : null

class User {
  String _name;
  String _email;
  String _image;
  dynamic _position;
  String _teamName;
  String _roleName;
  dynamic _committee;
  dynamic _role;

  String get name => _name;
  String get email => _email;
  String get image => _image;
  dynamic get position => _position;
  String get teamName => _teamName;
  String get roleName => _roleName;
  dynamic get committee => _committee;
  dynamic get role => _role;

  User({
      String name, 
      String email, 
      String image, 
      dynamic position, 
      String teamName, 
      String roleName, 
      dynamic committee, 
      dynamic role}){
    _name = name;
    _email = email;
    _image = image;
    _position = position;
    _teamName = teamName;
    _roleName = roleName;
    _committee = committee;
    _role = role;
}

  User.fromJson(dynamic json) {
    _name = json['name'];
    _email = json['email'];
    _image = json['image'];
    _position = json['position'];
    _teamName = json['team_name'];
    _roleName = json['role_name'];
    _committee = json['committee'];
    _role = json['role'];
  }

  Map<String, dynamic> toJson() {
    var map = <String, dynamic>{};
    map['name'] = _name;
    map['email'] = _email;
    map['image'] = _image;
    map['position'] = _position;
    map['team_name'] = _teamName;
    map['role_name'] = _roleName;
    map['committee'] = _committee;
    map['role'] = _role;
    return map;
  }

}

/// id : 350
/// meeting_id : 159
/// user_id : 35
/// user_email : ""
/// can_edit : 0
/// attendance_status : "Pending"
/// status_reason : null
/// user : {"name":"Mazin F","email":"Mazin@ijtimaati.com","image":"http://test.ijtimaati.com/api/public/uploads/images/UEvcaAL11E.jpeg","position":"IT Support","team_name":"","role_name":"","committee":null,"role":null}
/// type : "Viewer"

class Current_member {
  int _id;
  int _meetingId;
  int _userId;
  String _userEmail;
  int _canEdit;
  String _attendanceStatus;
  dynamic _statusReason;
  User _user;
  String _type;

  int get id => _id;
  int get meetingId => _meetingId;
  int get userId => _userId;
  String get userEmail => _userEmail;
  int get canEdit => _canEdit;
  String get attendanceStatus => _attendanceStatus;
  dynamic get statusReason => _statusReason;
  User get user => _user;
  String get type => _type;

  Current_member({
      int id, 
      int meetingId, 
      int userId, 
      String userEmail, 
      int canEdit, 
      String attendanceStatus, 
      dynamic statusReason, 
      User user, 
      String type}){
    _id = id;
    _meetingId = meetingId;
    _userId = userId;
    _userEmail = userEmail;
    _canEdit = canEdit;
    _attendanceStatus = attendanceStatus;
    _statusReason = statusReason;
    _user = user;
    _type = type;
}

  Current_member.fromJson(dynamic json) {
    _id = json['id'];
    _meetingId = json['meeting_id'];
    _userId = json['user_id'];
    _userEmail = json['user_email'];
    _canEdit = json['can_edit'];
    _attendanceStatus = json['attendance_status'];
    _statusReason = json['status_reason'];
    _user = json['user'] != null ? User.fromJson(json['user']) : null;
    _type = json['type'];
  }

  Map<String, dynamic> toJson() {
    var map = <String, dynamic>{};
    map['id'] = _id;
    map['meeting_id'] = _meetingId;
    map['user_id'] = _userId;
    map['user_email'] = _userEmail;
    map['can_edit'] = _canEdit;
    map['attendance_status'] = _attendanceStatus;
    map['status_reason'] = _statusReason;
    if (_user != null) {
      map['user'] = _user.toJson();
    }
    map['type'] = _type;
    return map;
  }

}



/// id : 58
/// meeting_id : 159
/// creator_id : 35
/// title : "Approval For the new system"
/// deadline : "2021-12-05 09:08:08"
/// description : null
/// order : 0
/// meeting : {"id":159,"title":"Ijtimaati management","owner_id":35,"committee_id":8,"description":"","start_date":"2021-12-13 09:52:00","duration":60,"location":null,"meeting_status_id":3,"virtual":0,"order":"TalkingPoints,Decisions,Actions","attendance_status":"Pending","last_activity":"Mazin F Update decision Approval For the new system 2021-12-05 10:58:36","current_member":{"id":350,"meeting_id":159,"user_id":35,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"user":{"name":"Mazin F","email":"Mazin@ijtimaati.com","image":"http://test.ijtimaati.com/api/public/uploads/images/UEvcaAL11E.jpeg","position":"IT Support","team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},"members":[{"id":347,"meeting_id":159,"user_id":21,"user_email":"","can_edit":0,"attendance_status":"Going","status_reason":null,"user":{"name":"Ahmed Zaid","email":"ahmed@ijtimaati.com","image":"http://test.ijtimaati.com/api/public/uploads/images/Ut7NK4RANu.jpg","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":350,"meeting_id":159,"user_id":35,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"user":{"name":"Mazin F","email":"Mazin@ijtimaati.com","image":"http://test.ijtimaati.com/api/public/uploads/images/UEvcaAL11E.jpeg","position":"IT Support","team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":348,"meeting_id":159,"user_id":37,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"user":{"name":"Jamila","email":"jamila@ijtimaati.com","image":"http://test.ijtimaati.com/api/public/uploads/images/zQD6FoVtg2.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":349,"meeting_id":159,"user_id":38,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"user":{"name":"Hilal","email":"hilal@ijtimaati.com","image":"http://test.ijtimaati.com/api/public/uploads/images/koU0KGKcAO.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"}]}

class Decision {
  int _id;
  int _meetingId;
  int _creatorId;
  String _title;
  String _deadline;
  dynamic _description;
  int _order;
  Meeting _meeting;

  int get id => _id;
  int get meetingId => _meetingId;
  int get creatorId => _creatorId;
  String get title => _title;
  String get deadline => _deadline;
  dynamic get description => _description;
  int get order => _order;
  Meeting get meeting => _meeting;

  Decision({
      int id, 
      int meetingId, 
      int creatorId, 
      String title, 
      String deadline, 
      dynamic description, 
      int order, 
      Meeting meeting}){
    _id = id;
    _meetingId = meetingId;
    _creatorId = creatorId;
    _title = title;
    _deadline = deadline;
    _description = description;
    _order = order;
    _meeting = meeting;
}

  Decision.fromJson(dynamic json) {
    _id = json['id'];
    _meetingId = json['meeting_id'];
    _creatorId = json['creator_id'];
    _title = json['title'];
    _deadline = json['deadline'];
    _description = json['description'];
    _order = json['order'];
    _meeting = json['meeting'] != null ? Meeting.fromJson(json['meeting']) : null;
  }

  Map<String, dynamic> toJson() {
    var map = <String, dynamic>{};
    map['id'] = _id;
    map['meeting_id'] = _meetingId;
    map['creator_id'] = _creatorId;
    map['title'] = _title;
    map['deadline'] = _deadline;
    map['description'] = _description;
    map['order'] = _order;
    if (_meeting != null) {
      map['meeting'] = _meeting.toJson();
    }
    return map;
  }

}




/// id : 350
/// meeting_id : 159
/// user_id : 35
/// user_email : ""
/// can_edit : 0
/// attendance_status : "Pending"
/// status_reason : null
/// user : {"name":"Mazin F","email":"Mazin@ijtimaati.com","image":"http://test.ijtimaati.com/api/public/uploads/images/UEvcaAL11E.jpeg","position":"IT Support","team_name":"","role_name":"","committee":null,"role":null}
/// type : "Viewer"



/// id : 82
/// meeting_id : 159
/// creator_id : 35
/// title : "Sales and Marketing Update"
/// duration : 60
/// description : "Last week update"
/// order : 0
/// meeting : {"id":159,"title":"Ijtimaati management","owner_id":35,"committee_id":8,"description":"","start_date":"2021-12-13 09:52:00","duration":60,"location":null,"meeting_status_id":3,"virtual":0,"order":"TalkingPoints,Decisions,Actions","attendance_status":"Pending","last_activity":"Mazin F Update decision Approval For the new system 2021-12-05 10:58:36","current_member":{"id":350,"meeting_id":159,"user_id":35,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"user":{"name":"Mazin F","email":"Mazin@ijtimaati.com","image":"http://test.ijtimaati.com/api/public/uploads/images/UEvcaAL11E.jpeg","position":"IT Support","team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},"members":[{"id":347,"meeting_id":159,"user_id":21,"user_email":"","can_edit":0,"attendance_status":"Going","status_reason":null,"user":{"name":"Ahmed Zaid","email":"ahmed@ijtimaati.com","image":"http://test.ijtimaati.com/api/public/uploads/images/Ut7NK4RANu.jpg","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":350,"meeting_id":159,"user_id":35,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"user":{"name":"Mazin F","email":"Mazin@ijtimaati.com","image":"http://test.ijtimaati.com/api/public/uploads/images/UEvcaAL11E.jpeg","position":"IT Support","team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":348,"meeting_id":159,"user_id":37,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"user":{"name":"Jamila","email":"jamila@ijtimaati.com","image":"http://test.ijtimaati.com/api/public/uploads/images/zQD6FoVtg2.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":349,"meeting_id":159,"user_id":38,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"user":{"name":"Hilal","email":"hilal@ijtimaati.com","image":"http://test.ijtimaati.com/api/public/uploads/images/koU0KGKcAO.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"}]}

class Talkingpoints {
  int _id;
  int _meetingId;
  int _creatorId;
  String _title;
  int _duration;
  String _description;
  int _order;
  Meeting _meeting;

  int get id => _id;
  int get meetingId => _meetingId;
  int get creatorId => _creatorId;
  String get title => _title;
  int get duration => _duration;
  String get description => _description;
  int get order => _order;
  Meeting get meeting => _meeting;

  Talkingpoints({
      int id, 
      int meetingId, 
      int creatorId, 
      String title, 
      int duration, 
      String description, 
      int order, 
      Meeting meeting}){
    _id = id;
    _meetingId = meetingId;
    _creatorId = creatorId;
    _title = title;
    _duration = duration;
    _description = description;
    _order = order;
    _meeting = meeting;
}

  Talkingpoints.fromJson(dynamic json) {
    _id = json['id'];
    _meetingId = json['meeting_id'];
    _creatorId = json['creator_id'];
    _title = json['title'];
    _duration = json['duration'];
    _description = json['description'];
    _order = json['order'];
    _meeting = json['meeting'] != null ? Meeting.fromJson(json['meeting']) : null;
  }

  Map<String, dynamic> toJson() {
    var map = <String, dynamic>{};
    map['id'] = _id;
    map['meeting_id'] = _meetingId;
    map['creator_id'] = _creatorId;
    map['title'] = _title;
    map['duration'] = _duration;
    map['description'] = _description;
    map['order'] = _order;
    if (_meeting != null) {
      map['meeting'] = _meeting.toJson();
    }
    return map;
  }

}









/// id : 159
/// title : "Ijtimaati management"
/// owner_id : 35
/// committee_id : 8
/// description : ""
/// start_date : "2021-12-13 09:52:00"
/// duration : 60
/// location : null
/// meeting_status_id : 3
/// virtual : 0
/// order : "TalkingPoints,Decisions,Actions"
/// attendance_status : "Pending"
/// last_activity : "Mazin F Update decision Approval For the new system 2021-12-05 10:58:36"
/// current_member : {"id":350,"meeting_id":159,"user_id":35,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"user":{"name":"Mazin F","email":"Mazin@ijtimaati.com","image":"http://test.ijtimaati.com/api/public/uploads/images/UEvcaAL11E.jpeg","position":"IT Support","team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"}
/// members : [{"id":347,"meeting_id":159,"user_id":21,"user_email":"","can_edit":0,"attendance_status":"Going","status_reason":null,"user":{"name":"Ahmed Zaid","email":"ahmed@ijtimaati.com","image":"http://test.ijtimaati.com/api/public/uploads/images/Ut7NK4RANu.jpg","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":350,"meeting_id":159,"user_id":35,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"user":{"name":"Mazin F","email":"Mazin@ijtimaati.com","image":"http://test.ijtimaati.com/api/public/uploads/images/UEvcaAL11E.jpeg","position":"IT Support","team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":348,"meeting_id":159,"user_id":37,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"user":{"name":"Jamila","email":"jamila@ijtimaati.com","image":"http://test.ijtimaati.com/api/public/uploads/images/zQD6FoVtg2.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":349,"meeting_id":159,"user_id":38,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"user":{"name":"Hilal","email":"hilal@ijtimaati.com","image":"http://test.ijtimaati.com/api/public/uploads/images/koU0KGKcAO.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"}]

class Draft {
  int _id;
  String _title;
  int _ownerId;
  int _committeeId;
  String _description;
  String _startDate;
  int _duration;
  dynamic _location;
  int _meetingStatusId;
  int _virtual;
  String _order;
  String _attendanceStatus;
  String _lastActivity;
  Current_member _currentMember;
  List<Members> _members;

  int get id => _id;
  String get title => _title;
  int get ownerId => _ownerId;
  int get committeeId => _committeeId;
  String get description => _description;
  String get startDate => _startDate;
  int get duration => _duration;
  dynamic get location => _location;
  int get meetingStatusId => _meetingStatusId;
  int get virtual => _virtual;
  String get order => _order;
  String get attendanceStatus => _attendanceStatus;
  String get lastActivity => _lastActivity;
  Current_member get currentMember => _currentMember;
  List<Members> get members => _members;

  Draft({
      int id, 
      String title, 
      int ownerId, 
      int committeeId, 
      String description, 
      String startDate, 
      int duration, 
      dynamic location, 
      int meetingStatusId, 
      int virtual, 
      String order, 
      String attendanceStatus, 
      String lastActivity, 
      Current_member currentMember, 
      List<Members> members}){
    _id = id;
    _title = title;
    _ownerId = ownerId;
    _committeeId = committeeId;
    _description = description;
    _startDate = startDate;
    _duration = duration;
    _location = location;
    _meetingStatusId = meetingStatusId;
    _virtual = virtual;
    _order = order;
    _attendanceStatus = attendanceStatus;
    _lastActivity = lastActivity;
    _currentMember = currentMember;
    _members = members;
}

  Draft.fromJson(dynamic json) {
    _id = json['id'];
    _title = json['title'];
    _ownerId = json['owner_id'];
    _committeeId = json['committee_id'];
    _description = json['description'];
    _startDate = json['start_date'];
    _duration = json['duration'];
    _location = json['location'];
    _meetingStatusId = json['meeting_status_id'];
    _virtual = json['virtual'];
    _order = json['order'];
    _attendanceStatus = json['attendance_status'];
    _lastActivity = json['last_activity'];
    _currentMember = json['current_member'] != null ? Current_member.fromJson(json['current_member']) : null;
    if (json['members'] != null) {
      _members = [];
      json['members'].forEach((v) {
        _members.add(Members.fromJson(v));
      });
    }
  }

  Map<String, dynamic> toJson() {
    var map = <String, dynamic>{};
    map['id'] = _id;
    map['title'] = _title;
    map['owner_id'] = _ownerId;
    map['committee_id'] = _committeeId;
    map['description'] = _description;
    map['start_date'] = _startDate;
    map['duration'] = _duration;
    map['location'] = _location;
    map['meeting_status_id'] = _meetingStatusId;
    map['virtual'] = _virtual;
    map['order'] = _order;
    map['attendance_status'] = _attendanceStatus;
    map['last_activity'] = _lastActivity;
    if (_currentMember != null) {
      map['current_member'] = _currentMember.toJson();
    }
    if (_members != null) {
      map['members'] = _members.map((v) => v.toJson()).toList();
    }
    return map;
  }

}





/// id : 159
/// title : "Ijtimaati management"
/// owner_id : 35
/// committee_id : 8
/// description : ""
/// start_date : "2021-12-13 09:52:00"
/// duration : 60
/// location : null
/// meeting_status_id : 3
/// virtual : 0
/// order : "TalkingPoints,Decisions,Actions"
/// attendance_status : "Pending"
/// last_activity : "Mazin F Update decision Approval For the new system 2021-12-05 10:58:36"
/// current_member : {"id":350,"meeting_id":159,"user_id":35,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"user":{"name":"Mazin F","email":"Mazin@ijtimaati.com","image":"http://test.ijtimaati.com/api/public/uploads/images/UEvcaAL11E.jpeg","position":"IT Support","team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"}
/// members : [{"id":347,"meeting_id":159,"user_id":21,"user_email":"","can_edit":0,"attendance_status":"Going","status_reason":null,"user":{"name":"Ahmed Zaid","email":"ahmed@ijtimaati.com","image":"http://test.ijtimaati.com/api/public/uploads/images/Ut7NK4RANu.jpg","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":350,"meeting_id":159,"user_id":35,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"user":{"name":"Mazin F","email":"Mazin@ijtimaati.com","image":"http://test.ijtimaati.com/api/public/uploads/images/UEvcaAL11E.jpeg","position":"IT Support","team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":348,"meeting_id":159,"user_id":37,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"user":{"name":"Jamila","email":"jamila@ijtimaati.com","image":"http://test.ijtimaati.com/api/public/uploads/images/zQD6FoVtg2.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":349,"meeting_id":159,"user_id":38,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"user":{"name":"Hilal","email":"hilal@ijtimaati.com","image":"http://test.ijtimaati.com/api/public/uploads/images/koU0KGKcAO.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"}]

class Pending {
  int _id;
  String _title;
  int _ownerId;
  int _committeeId;
  String _description;
  String _startDate;
  int _duration;
  dynamic _location;
  int _meetingStatusId;
  int _virtual;
  String _order;
  String _attendanceStatus;
  String _lastActivity;
  Current_member _currentMember;
  List<Members> _members;

  int get id => _id;
  String get title => _title;
  int get ownerId => _ownerId;
  int get committeeId => _committeeId;
  String get description => _description;
  String get startDate => _startDate;
  int get duration => _duration;
  dynamic get location => _location;
  int get meetingStatusId => _meetingStatusId;
  int get virtual => _virtual;
  String get order => _order;
  String get attendanceStatus => _attendanceStatus;
  String get lastActivity => _lastActivity;
  Current_member get currentMember => _currentMember;
  List<Members> get members => _members;

  Pending({
      int id, 
      String title, 
      int ownerId, 
      int committeeId, 
      String description, 
      String startDate, 
      int duration, 
      dynamic location, 
      int meetingStatusId, 
      int virtual, 
      String order, 
      String attendanceStatus, 
      String lastActivity, 
      Current_member currentMember, 
      List<Members> members}){
    _id = id;
    _title = title;
    _ownerId = ownerId;
    _committeeId = committeeId;
    _description = description;
    _startDate = startDate;
    _duration = duration;
    _location = location;
    _meetingStatusId = meetingStatusId;
    _virtual = virtual;
    _order = order;
    _attendanceStatus = attendanceStatus;
    _lastActivity = lastActivity;
    _currentMember = currentMember;
    _members = members;
}

  Pending.fromJson(dynamic json) {
    _id = json['id'];
    _title = json['title'];
    _ownerId = json['owner_id'];
    _committeeId = json['committee_id'];
    _description = json['description'];
    _startDate = json['start_date'];
    _duration = json['duration'];
    _location = json['location'];
    _meetingStatusId = json['meeting_status_id'];
    _virtual = json['virtual'];
    _order = json['order'];
    _attendanceStatus = json['attendance_status'];
    _lastActivity = json['last_activity'];
    _currentMember = json['current_member'] != null ? Current_member.fromJson(json['current_member']) : null;
    if (json['members'] != null) {
      _members = [];
      json['members'].forEach((v) {
        _members.add(Members.fromJson(v));
      });
    }
  }

  Map<String, dynamic> toJson() {
    var map = <String, dynamic>{};
    map['id'] = _id;
    map['title'] = _title;
    map['owner_id'] = _ownerId;
    map['committee_id'] = _committeeId;
    map['description'] = _description;
    map['start_date'] = _startDate;
    map['duration'] = _duration;
    map['location'] = _location;
    map['meeting_status_id'] = _meetingStatusId;
    map['virtual'] = _virtual;
    map['order'] = _order;
    map['attendance_status'] = _attendanceStatus;
    map['last_activity'] = _lastActivity;
    if (_currentMember != null) {
      map['current_member'] = _currentMember.toJson();
    }
    if (_members != null) {
      map['members'] = _members.map((v) => v.toJson()).toList();
    }
    return map;
  }

}

/// id : 347
/// meeting_id : 159
/// user_id : 21
/// user_email : ""
/// can_edit : 0
/// attendance_status : "Going"
/// status_reason : null
/// user : {"name":"Ahmed Zaid","email":"ahmed@ijtimaati.com","image":"http://test.ijtimaati.com/api/public/uploads/images/Ut7NK4RANu.jpg","position":null,"team_name":"","role_name":"","committee":null,"role":null}
/// type : "Viewer"




/// id : 350
/// meeting_id : 159
/// user_id : 35
/// user_email : ""
/// can_edit : 0
/// attendance_status : "Pending"
/// status_reason : null
/// user : {"name":"Mazin F","email":"Mazin@ijtimaati.com","image":"http://test.ijtimaati.com/api/public/uploads/images/UEvcaAL11E.jpeg","position":"IT Support","team_name":"","role_name":"","committee":null,"role":null}
/// type : "Viewer"




/// id : 159
/// title : "Ijtimaati management"
/// owner_id : 35
/// committee_id : 8
/// description : ""
/// start_date : "2021-12-13 09:52:00"
/// duration : 60
/// location : null
/// meeting_status_id : 3
/// virtual : 0
/// order : "TalkingPoints,Decisions,Actions"
/// attendance_status : "Pending"
/// last_activity : "Mazin F Update decision Approval For the new system 2021-12-05 10:58:36"
/// current_member : {"id":350,"meeting_id":159,"user_id":35,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"user":{"name":"Mazin F","email":"Mazin@ijtimaati.com","image":"http://test.ijtimaati.com/api/public/uploads/images/UEvcaAL11E.jpeg","position":"IT Support","team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"}
/// members : [{"id":347,"meeting_id":159,"user_id":21,"user_email":"","can_edit":0,"attendance_status":"Going","status_reason":null,"user":{"name":"Ahmed Zaid","email":"ahmed@ijtimaati.com","image":"http://test.ijtimaati.com/api/public/uploads/images/Ut7NK4RANu.jpg","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":350,"meeting_id":159,"user_id":35,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"user":{"name":"Mazin F","email":"Mazin@ijtimaati.com","image":"http://test.ijtimaati.com/api/public/uploads/images/UEvcaAL11E.jpeg","position":"IT Support","team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":348,"meeting_id":159,"user_id":37,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"user":{"name":"Jamila","email":"jamila@ijtimaati.com","image":"http://test.ijtimaati.com/api/public/uploads/images/zQD6FoVtg2.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"},{"id":349,"meeting_id":159,"user_id":38,"user_email":"","can_edit":0,"attendance_status":"Pending","status_reason":null,"user":{"name":"Hilal","email":"hilal@ijtimaati.com","image":"http://test.ijtimaati.com/api/public/uploads/images/koU0KGKcAO.png","position":null,"team_name":"","role_name":"","committee":null,"role":null},"type":"Viewer"}]

class Ongoing {
  int _id;
  String _title;
  int _ownerId;
  int _committeeId;
  String _description;
  String _startDate;
  int _duration;
  dynamic _location;
  int _meetingStatusId;
  int _virtual;
  String _order;
  String _attendanceStatus;
  String _lastActivity;
  Current_member _currentMember;
  List<Members> _members;

  int get id => _id;
  String get title => _title;
  int get ownerId => _ownerId;
  int get committeeId => _committeeId;
  String get description => _description;
  String get startDate => _startDate;
  int get duration => _duration;
  dynamic get location => _location;
  int get meetingStatusId => _meetingStatusId;
  int get virtual => _virtual;
  String get order => _order;
  String get attendanceStatus => _attendanceStatus;
  String get lastActivity => _lastActivity;
  Current_member get currentMember => _currentMember;
  List<Members> get members => _members;

  Ongoing({
      int id, 
      String title, 
      int ownerId, 
      int committeeId, 
      String description, 
      String startDate, 
      int duration, 
      dynamic location, 
      int meetingStatusId, 
      int virtual, 
      String order, 
      String attendanceStatus, 
      String lastActivity, 
      Current_member currentMember, 
      List<Members> members}){
    _id = id;
    _title = title;
    _ownerId = ownerId;
    _committeeId = committeeId;
    _description = description;
    _startDate = startDate;
    _duration = duration;
    _location = location;
    _meetingStatusId = meetingStatusId;
    _virtual = virtual;
    _order = order;
    _attendanceStatus = attendanceStatus;
    _lastActivity = lastActivity;
    _currentMember = currentMember;
    _members = members;
}

  Ongoing.fromJson(dynamic json) {
    _id = json['id'];
    _title = json['title'];
    _ownerId = json['owner_id'];
    _committeeId = json['committee_id'];
    _description = json['description'];
    _startDate = json['start_date'];
    _duration = json['duration'];
    _location = json['location'];
    _meetingStatusId = json['meeting_status_id'];
    _virtual = json['virtual'];
    _order = json['order'];
    _attendanceStatus = json['attendance_status'];
    _lastActivity = json['last_activity'];
    _currentMember = json['current_member'] != null ? Current_member.fromJson(json['current_member']) : null;
    if (json['members'] != null) {
      _members = [];
      json['members'].forEach((v) {
        _members.add(Members.fromJson(v));
      });
    }
  }

  Map<String, dynamic> toJson() {
    var map = <String, dynamic>{};
    map['id'] = _id;
    map['title'] = _title;
    map['owner_id'] = _ownerId;
    map['committee_id'] = _committeeId;
    map['description'] = _description;
    map['start_date'] = _startDate;
    map['duration'] = _duration;
    map['location'] = _location;
    map['meeting_status_id'] = _meetingStatusId;
    map['virtual'] = _virtual;
    map['order'] = _order;
    map['attendance_status'] = _attendanceStatus;
    map['last_activity'] = _lastActivity;
    if (_currentMember != null) {
      map['current_member'] = _currentMember.toJson();
    }
    if (_members != null) {
      map['members'] = _members.map((v) => v.toJson()).toList();
    }
    return map;
  }

}

/// id : 347
/// meeting_id : 159
/// user_id : 21
/// user_email : ""
/// can_edit : 0
/// attendance_status : "Going"
/// status_reason : null
/// user : {"name":"Ahmed Zaid","email":"ahmed@ijtimaati.com","image":"http://test.ijtimaati.com/api/public/uploads/images/Ut7NK4RANu.jpg","position":null,"team_name":"","role_name":"","committee":null,"role":null}
/// type : "Viewer"


/// name : "Ahmed Zaid"
/// email : "ahmed@ijtimaati.com"
/// image : "http://test.ijtimaati.com/api/public/uploads/images/Ut7NK4RANu.jpg"
/// position : null
/// team_name : ""
/// role_name : ""
/// committee : null
/// role : null


/// id : 350
/// meeting_id : 159
/// user_id : 35
/// user_email : ""
/// can_edit : 0
/// attendance_status : "Pending"
/// status_reason : null
/// user : {"name":"Mazin F","email":"Mazin@ijtimaati.com","image":"http://test.ijtimaati.com/api/public/uploads/images/UEvcaAL11E.jpeg","position":"IT Support","team_name":"","role_name":"","committee":null,"role":null}
/// type : "Viewer"


