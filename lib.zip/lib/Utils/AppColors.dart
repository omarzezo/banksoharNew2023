import 'package:flutter/material.dart';

const grayColor =  Color(0xffFAFAFB);
const gray2 =  Color(0xffe8eaed);
const grayRoundedColor =  Color(0xffEDF2F9);
// const grayTextColor =  Color(0xff7F8FA4);
const grayTextColor =  Color(0xff7F8FA4);
const blueColor =  Color(0xff1A3353);
const yellowColor =  Color(0xffFEC20E);
const whiteColor =  Color(0xffffffff);
const greenColor =  Color(0xff00826E);
// const yellowLightColor =  Color(0xfffff9e6);
const yellowLightColor =  Color(0xfffff7e5);
// const yellowLightColor =  Color(0xffC7d4d4);

const m =Color(0xffe7f0ff);